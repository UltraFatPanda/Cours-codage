1 - `npm i` pour installer les dépendance
2 - Entrer son MONGO URI perso dans .env enfin de se connecter à sa base de donnée
